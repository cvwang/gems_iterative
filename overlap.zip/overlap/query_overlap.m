function x =query_overlap (E_extra,L_inv,U_inv,L_k_inv,U_k_inv,T1,H3,total_nodes,cluster_b_start,s,n,nparts,c)
total_in=cell(1,nparts);
total_boundary=cell(1,nparts);
L_inv2=cell(nparts,1);
U_inv2=cell(nparts,1);
for i=1:nparts
    if (cluster_b_start(i)<=length(total_nodes{i}))
        if (cluster_b_start(i)~=1)
            total_in{i}=total_nodes{i}(1:cluster_b_start(i)-1);
        else
            total_in{i}=1;      %if there are no inner nodes but there are boundary nodes
        end
        total_boundary{i}=total_nodes{i}(cluster_b_start(i):end);
        L_inv2{i}=L_inv{i}(:,cluster_b_start(i):end);
        U_inv2{i}=U_inv{i};
    end
end
L_inv2=blkdiag(L_inv2{:});
U_inv2=blkdiag(U_inv2{:});
L_inv=blkdiag(L_inv{:});
U_inv=blkdiag(U_inv{:});
total_in=cell2mat(total_in);
total_boundary=cell2mat(total_boundary);
total_nodes_mat=cell2mat(total_nodes);
y=sparse(n,1);
x=sparse(n,1);
y(s)=1-c;
y_i=y(total_in);
y_b=y(total_boundary);
q=E_extra*(H3*y_i)+T1*y_b;
f=U_k_inv*(L_k_inv*q);
e=U_inv2*(L_inv2*f);
ori=U_inv*(L_inv*y(total_nodes_mat));
j=1;
k=1;
for i=1:nparts
    l=length(total_nodes{i});
    if (cluster_b_start(i)<=length(total_nodes{i}))
        x(total_nodes{i})=ori(k:k+l-1)+e(j:j+l-1);
        j=j+l;
    else
        x(total_nodes{i})=ori(k:k+l-1);
    end
    k=k+l;
end
end