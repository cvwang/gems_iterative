clear;
%runtime version
A=spconvert(load('out.moreno_blogs_blogs'));
partition_list=load('partition_list_moreno.txt');
partition_list=partition_list(2:end,2);
n=max(size(A));%number of nodes
A(n,n)=0;
nparts=max(partition_list);
d=1;
c=0.85;
tic
[E_extra,L_inv,U_inv,L_k_inv,U_k_inv,T1,H3,total_nodes,cluster_b_start] =Preprocess_overlap (partition_list,nparts,n,A,d,c);
time = toc;
display('preprocessing time');
fprintf('%f\n', time);
n_q = 1;
query_nodes = randi(n, n_q, 1);
display('query time');
x=cell(n_q,1);
tic
for q=1:n_q
    x{q} =query_overlap (E_extra,L_inv,U_inv,L_k_inv,U_k_inv,T1,H3,total_nodes,cluster_b_start,query_nodes(q),n,nparts,c);
end
time = toc;
fprintf('%f\n', time/n_q);


if(~d)
    A=A+A';
else
    A=A';
end
vec = sum(A, 1);
vec = bsxfun(@max, vec, 1);
vec = 1 ./ vec;
D = spdiags(vec(:),0,n,n);
E=c*A*D;
I=speye(size(E));
y=sparse(n,1);
y(query_nodes(1))=1-c;
x_standard=(I-E)\y;
le=x{1,1}-x_standard;
max(abs(le))

