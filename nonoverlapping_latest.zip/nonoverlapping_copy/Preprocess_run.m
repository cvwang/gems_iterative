function [E_boundary,node_reorder2,L_inv,U_inv,L_k_inv,U_k_inv,boundary_start_number,index_starter,T1,H3] =Preprocess_run (partition_list,nparts,n,A,d,c)
if(~d)
    A=A+A';
else
    A=A';
end
vec = sum(A, 1);
vec = bsxfun(@max, vec, 1);
vec = 1 ./ vec;
D = spdiags(vec(:),0,n,n);
E=c*A*D;
boundary_list=find_boundary_run (A,partition_list,n);
[node_reorder2,E_boundary,reorder_E,index_starter,boundary_start_number]=Reordering_run(partition_list,boundary_list,nparts,n,E);
[L_inv,U_inv,L_k_inv,U_k_inv,T1,H3]=flow_run (E_boundary,reorder_E,index_starter,boundary_start_number,n,nparts);
end
