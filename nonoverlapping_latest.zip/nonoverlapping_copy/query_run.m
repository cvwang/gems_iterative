function x=query_run(E_boundary,T1,H3,L_inv,U_inv,L_k_inv,U_k_inv,boundary_start_number,index_starter,nparts,n,node_reorder2,c,q)
c=1-c;
[~,reverse_map]=sort(node_reorder2);
r_q=reverse_map(q); %query node of current ordering
ori=c*U_inv*L_inv(:,r_q);
group_ori=find(r_q<index_starter,1);
if (group_ori)
    group=group_ori-1;
else
    group=nparts;
end
inner_num=boundary_start_number-index_starter;
inner_num_adj=inner_num;
inner_num_adj(inner_num_adj==0)=1;
index_end=[index_starter(2:end)-1;n];
inner_num_adj(boundary_start_number==index_end+1)=0;
boundary_number=index_end-boundary_start_number+1;
b_start=cumsum([1;boundary_number]);
b_start=b_start(1:end-1);
b_end=[b_start(2:end)-1;size(E_boundary,1)];
if (r_q<boundary_start_number(group)) %the query node is an internal node
    if(group==1)
        s_i=r_q;
    else
        s_i=sum(inner_num_adj(1:group-1))+r_q-index_starter(group)+1;
    end
    b=c*E_boundary*H3(:,s_i);
else
    s_i=r_q-sum(inner_num(1:group));
    b=c*T1(:,s_i);
end
f=U_k_inv*(L_k_inv*b);
e=sparse(n,1);
for i=1:nparts
    if (boundary_number(i))
        e(index_starter(i):index_end(i))=U_inv(index_starter(i):index_end(i),index_starter(i):index_end(i))*(L_inv(index_starter(i):index_end(i),boundary_start_number(i):index_end(i))*f(b_start(i):b_end(i)));
    end
end
x=ori+e;
x=x(reverse_map);
end

