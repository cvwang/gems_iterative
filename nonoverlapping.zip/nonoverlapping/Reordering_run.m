function [node_reorder2,E_boundary,reorder_E,index_starter,boundary_start_number]=Reordering_run(partition_list,boundary_list,nparts,n,E)
[B,node_reorder1]=sort(partition_list);
index_starter=find(diff([0;B]));
index_end=[index_starter(2:end)-1;n];

boundary_group=partition_list(boundary_list);
[B,boundary_reorder1]=sort(boundary_group);
boundary_reorder_list=boundary_list(boundary_reorder1);
E_boundary=E(boundary_reorder_list,boundary_reorder_list);
dif_b=diff([0;B]);
bound_start=find(dif_b);
l=length(boundary_list);
bound_end=[bound_start(2:end)-1;l];

[~,v]=ismember(boundary_list,node_reorder1);
node_reorder1(v)=0; 
C=node_reorder1(node_reorder1~=0);
B=partition_list(C);
dif_i=diff([0;B]);
inner_start=find(dif_i);
inner_end=[inner_start(2:end)-1;length(C)];



j=1;
for i=1:length(bound_end)
    E_boundary(j:bound_end(i)-bound_start(i)+j,j:bound_end(i)-bound_start(i)+j)=0;
    j=bound_end(i)-bound_start(i)+j+1;
end

boundary_start_number=index_end+1;
node_reorder2=zeros(n,1);

j=1;
k=1;
for i=1:nparts
    if(j<=length(inner_start))
        if (dif_i(inner_start(j))==1)
            node_reorder2(index_starter(i):inner_end(j)-inner_start(j)+index_starter(i))=C(inner_start(j):inner_end(j));
            if (index_end(i)~=inner_end(j)-inner_start(j)+index_starter(i))% boundary nodes exist
                boundary_start_number(i)=inner_end(j)-inner_start(j)+index_starter(i)+1;
                node_reorder2(boundary_start_number(i):index_end(i))=boundary_reorder_list(bound_start(k):bound_end(k));
                k=k+1;
            end
            j=j+1;
        else
            dif_i(inner_start(j))=dif_i(inner_start(j))-1;
            node_reorder2(index_starter(i):index_end(i))=boundary_reorder_list(bound_start(k):bound_end(k));%all the nodes must be boundary nodes
            boundary_start_number(i)=index_starter(i);
            k=k+1;
        end
    else
        node_reorder2(index_starter(i):index_end(i))=boundary_reorder_list(bound_start(k):bound_end(k));%all the nodes must be boundary nodes
        boundary_start_number(i)=index_starter(i);
        k=k+1; 
    end
end
reorder_E=E(node_reorder2,node_reorder2);