function [L_inv,U_inv,L_k_inv,U_k_inv,T1,H3]=flow_run (E_boundary,reorder_E,index_starter,boundary_start_number,n,nparts)
%%
%preprocessing
index_end=[index_starter(2:end)-1;n];
boundary_number=index_end-boundary_start_number+1;
b=sum(boundary_number);
b_start=cumsum([1;boundary_number]);
b_start=b_start(1:end-1);
b_end=[b_start(2:end)-1;b];
H3=cell(nparts,1);
H4=cell(nparts,1);
L=cell(nparts,1);
U=cell(nparts,1);
wi=cell(nparts,1);
T1=sparse(b,b);

for i=1:nparts
    wi{i}=speye(index_end(i)-index_starter(i)+1)-reorder_E(index_starter(i):index_end(i),index_starter(i):index_end(i));
    [L{i},U{i}]=lu(wi{i});  %Define U{i}*L{i}=H{i}
    L{i}=L{i}^(-1);         %H{i} can be divided into four parts:
    U{i}=U{i}^(-1);         %H{i}=[H1,H2;H3,H4]
                            %however, here we did not compute H{i}, but
                            %directly compute H3 and H4
    if(boundary_start_number(i)~=index_end(i)+1)
        if(boundary_start_number(i)~=index_starter(i))
            H3{i}=U{i}(boundary_start_number(i)-index_starter(i)+1:end,:)*L{i}(:,1:boundary_start_number(i)-index_starter(i));
        else
            H3{i}=sparse(boundary_number(i),1);
        end
        H4{i}=U{i}(boundary_start_number(i)-index_starter(i)+1:end,:)*L{i}(:,boundary_start_number(i)-index_starter(i)+1:end);
        T1(:,b_start(i):b_end(i))=E_boundary(:,b_start(i):b_end(i))*H4{i};
    end
end

L_inv=blkdiag(L{:}); %put all the matrices in block diagnal form
U_inv=blkdiag(U{:});
H3=blkdiag(H3{:});


%%
%main equation
I=speye(size(E_boundary));
T=I-T1;
%display('time of lu decomposition for T')
[L,U]=lu(T);
%display('inverse for L & U')
L_k_inv=L^(-1);
U_k_inv=U^(-1);
end

