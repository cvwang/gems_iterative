%runtime version
A=spconvert(load('out.moreno_blogs_blogs'));
partition_list=load('partition_list_moreno.txt');
partition_list=partition_list(2:end,2);
nparts=max(partition_list);
n=max(size(A));%number of nodes
A(n,n)=0;
c=0.85;
d=1;
tic
[E_boundary,node_reorder2,L_inv,U_inv,L_k_inv,U_k_inv,boundary_start_number,index_starter,T1,H3] =Preprocess_run (partition_list,nparts,n,A,d,c);
time=toc;
display('preprocessing time');
fprintf('%f\n', time);
n_q = 1;
query_nodes = randi(n, n_q, 1);
tic
x=cell(n_q,1);
for q=1:n_q
    x{q}=query_run(E_boundary,T1,H3,L_inv,U_inv,L_k_inv,U_k_inv,boundary_start_number,index_starter,nparts,n,node_reorder2,c,query_nodes(q));
end
time=toc;
display('query time');
fprintf('%f\n', time/n_q);


if(~d)
    A=A+A';
else
    A=A';
end
vec = sum(A, 1);
vec = bsxfun(@max, vec, 1);
vec = 1 ./ vec;
D = spdiags(vec(:),0,n,n);
E=c*A*D;
I=speye(size(E));
y=sparse(n,1);
y(query_nodes(1))=1-c;
x_standard=(I-E)\y;
le=x{1,1}-x_standard;
max(abs(le))

%exit;
