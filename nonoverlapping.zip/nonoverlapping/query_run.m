function x=query_run(E_boundary,T1,H3,L_inv,U_inv,L_k_inv,U_k_inv,boundary_start_number,index_starter,nparts,n,node_reorder2,c,q)
y=zeros(n,1);
[~,reverse_map]=sort(node_reorder2);
y(reverse_map(q))=(1-c);
y_b=cell(nparts,1);
y_i=cell(nparts,1);
e=zeros(n,1);
index_end=[index_starter(2:end)-1;n];
boundary_number=index_end-boundary_start_number+1;
b_start=cumsum([1;boundary_number]);
b_start=b_start(1:end-1);
b_end=[b_start(2:end)-1;size(E_boundary,1)];
for i=1:nparts
    if(boundary_start_number(i)<=index_end(i)) %boundary nodes exsit
        y_b{i}=y(boundary_start_number(i):index_end(i));%put all the boundary nodes together in group sequence
        if(boundary_start_number(i)~=index_starter(i)) %inner nodes exist
            y_i{i}=y(index_starter(i):boundary_start_number(i)-1);
        else
            y_i{i}=0;
        end
    end
end
y_b=sparse(cell2mat(y_b));
y_i=sparse(cell2mat(y_i));
y=sparse(y);
ori=U_inv*(L_inv*y);
b=T1*y_b+E_boundary*(H3*y_i);
f=U_k_inv*(L_k_inv*b);
for i=1:nparts
    if (boundary_number(i))
        e(index_starter(i):index_end(i))=U_inv(index_starter(i):index_end(i),index_starter(i):index_end(i))*(L_inv(index_starter(i):index_end(i),boundary_start_number(i):index_end(i))*f(b_start(i):b_end(i)));
    end
end
e=sparse(e);
x=ori+e;
x=sparse(x(reverse_map));
end